    <meta name="description" content="SABR Respublika ijtimoiy-iqtisodiy rivojlanish markazi | Tinglovchilarni ro'yxatga olish tizimi">
        
    <!-- Open Graph Meta-->
    <meta property="og:type" content="webapp">
    <meta property="og:site_name" content="SABR">
    <meta property="og:title" content="SABR Respublika ijtimoiy-iqtisodiy rivojlanish markazi | Tinglovchilarni ro'yxatga olish tizimi">
    <meta property="og:url" content="http://sabr.uz">
    <meta property="og:image" content="https://sabr.uz/res/images/logo.png">
    <meta property="og:description" content="SABR Respublika ijtimoiy-iqtisodiy rivojlanish markazi | Tinglovchilarni ro'yxatga olish tizimi">
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="icon" href="images/favicon.ico" type="image/x-icon">    
    <!-- Main CSS-->
    <link rel="stylesheet" type="text/css" href="css/main.css">
    <!-- Font-icon css-->
    <link rel="stylesheet" type="text/css" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
    <title>ADMIN OYNASI | Tinglovchilarni ro'yxatga olish tizimi</title>
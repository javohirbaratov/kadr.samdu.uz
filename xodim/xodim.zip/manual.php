<?php
include_once 'ximoya.php';
$_SESSION['page'] = 1;
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <?php include_once 'css.php'; ?>
</head>
<body class="app sidebar-mini">
<?php include_once 'header.php'; ?>
<main class="app-content">

</main>
<?php include_once 'js.php'; ?>
</body>
</html>
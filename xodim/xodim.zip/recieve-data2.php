<?php
    include_once 'ximoya.php';
    $_SESSION['page'] =152;
?>
<!DOCTYPE html>
<html lang="en">
  <head>
    <? include_once 'css.php'; ?>
  </head>
  <body class="app sidebar-mini">
    <? include_once 'header.php'; ?>
    <main class="app-content">
      <div class="app-title">
          <div>
            <h1><i class="fa fa-th-list"></i> Qabul qilingan malumotlar</h1>
            <p>Qabul qilingan malumotlarni qulay tarzda saralash va ular ustida tezkor amallarni bajarish</p>
          </div>
          <ul class="app-breadcrumb breadcrumb side">
            <li class="breadcrumb-item"><i class="fa fa-home fa-lg"></i></li>
            <li class="breadcrumb-item">Kurslar</li>
            <li class="breadcrumb-item active"><a href="#">Kurslarni ko'rish</a></li>
          </ul>
        </div>
        <div class="row">
          <div class="col-md-12">
            <div class="tile">
              <div class="tile-body">
               
                <div class="table-responsive">
                  <table class="table table-hover table-bordered" id="sampleTable">
                    <thead>
                      <tr>
                        <th>Nomer</th>
                        <th>Rasm</th>
                         
                        <th>F.I.SH</th>
                        <th>Pasport SN</th>
                        <th>Jshshir</th>
                        <th>Telefon</th>
                        <th>Pasport</th>
                        <th>Manzil</th>
                        <th>Amallar</th>
                      </tr>
                    </thead>
                    <tbody>
                        <?
                            $t=0;
                            $sql = mysqli_query($link,"SELECT * FROM xodimlar  ORDER BY id ASC");
                            while($fetch = mysqli_fetch_assoc($sql)){
                                $t++;                               
                        ?>
                        <tr>
                        <td><?=$fetch['id']?></td>
                        <td><img src="../bot/uploads/<?=$fetch['rasm']?>" width="50"></td>
                        <td><?=$fetch['familya']?> <?=$fetch['ism']?> <?=$fetch['otch']?></td>
                         <td><?=$fetch['nomer']?></td>
                         
                          <td><?=$fetch['jshir']?></td>
                          <td><?=$fetch['telefon']?></td>
                          <td><a href ="../bot/uploads/<?=$fetch['passport']?>" >Pasport</a></td>
                          <td><?=$fetch['manzil']?></td>
                        <td><a href="xodim-view.php?id=<?=$fetch['id']?>" class="btn btn-success"><i class="fa fa-eye"></i> Batafsil</a>
                           
                            
                        </td>
                      </tr>
                        <?}?>
                    </tbody>
                  </table>
                </div>
              </div>
            </div>
          </div>
        </div>    
    </main>
    <? include_once 'js.php'; ?>
    <script type="text/javascript">
        function udalit(id) {
            swal({
                title: "O'chirishga ishonchingiuz komilmi?",
                text: "O'chirilgan malumot qayta tiklanmaydi!",
                type: "warning",
                showCancelButton: true,
                confirmButtonText: "Ha, o'chir!",
                cancelButtonText: "Yo'q, bekor qil!",
                closeOnConfirm: false,
                closeOnCancel: false
            }, function(isConfirm) {
                if (isConfirm) {
                    $.ajax({
                        url: "user-delete.php",
                        type: "POST",
                        data:{
                            course_id:id,action:"kurslar",
                        },
                        success:function(data) {
                            var obj = jQuery.parseJSON(data);
                            if(obj.error==0){
                                swal("O'chirildi!", "Muvaffaqqiyatli o'chirildi", "success");
                                $('#tr'+id).remove();
                            }
                            else{
                                swal("O'chirilmadi", "Ichki xatolik, qaytadan urinib ko'ring", "error");        
                            }
                        },
                        error:function(xhr) {
                            swal("O'chirilmadi", "Internetdan uzilish ro'y berdi", "error");        
                        }
                    });                 
                } else {
                    swal("Bekor qilindi", "Obyekt o'chirilishi bekor qilindi :)", "error");
                }
            });
        }
    </script>
  </body>
</html>
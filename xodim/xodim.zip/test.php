<?php 
	include_once 'file';
?>
<?
	include_once 'ximoya.php';
	$ret = [];
	

	if($_GET['action']=="lavozim"){
		$id = $_GET['id'];
		$sql = mysqli_query($link,"DELETE FROM lavozimlar WHERE id='$id'");
		if ($sql==true) {
			$ret = ["err" => 0, "msg" => "Muvaffaqqiyatli amalga oshdi"];
		}
		else{
			$ret = ["err" => 1, "msg" => "Amalga oshmadi"];
		}
	}


	echo json_encode($ret);
?>